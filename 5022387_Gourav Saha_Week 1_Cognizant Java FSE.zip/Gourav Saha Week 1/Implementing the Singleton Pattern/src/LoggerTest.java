
public class LoggerTest {
	    public static void main(String[] args) {
	        // Get two instances of Logger
	        Logger logger1 = Logger.getInstance();
	        Logger logger2 = Logger.getInstance();

	        // Check if both instances are the same
	        if (logger1 == logger2) {
	            System.out.println("Singleton pattern is working: Both instances are the same.");
	        } else {
	            System.out.println("Singleton pattern is not working: Instances are different.");
	        }

	        // Use the logger to log messages
	        logger1.log("This is a log message from logger1.");
	        logger2.log("This is a log message from logger2.");
	    }
	}

