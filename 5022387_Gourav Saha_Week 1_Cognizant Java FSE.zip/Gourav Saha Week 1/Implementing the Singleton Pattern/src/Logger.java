
public class Logger {
	 // Step 1: Private static instance of Logger class
    private static Logger instance;

    // Step 2: Private constructor to prevent instantiation from outside
    private Logger() {
        // Initialize any resources if needed
    }

    // Step 3: Public static method to provide access to the instance
    public static synchronized Logger getInstance() {
        if (instance == null) {
            instance = new Logger();
        }
        return instance;
    }

    // Example logging method
    public void log(String message) {
        System.out.println("LOG: " + message);
    }

}
